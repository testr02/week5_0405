package test.while1;

public class SimpleFor {

}
